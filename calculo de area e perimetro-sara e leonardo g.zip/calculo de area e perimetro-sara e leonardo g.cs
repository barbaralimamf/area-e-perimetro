﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa
{
    class Program
    {
        static void Main(string[] args)
        {
            double n1, n2, n3, n4, resultado;
            int opcao;

            do
            {
                Console.WriteLine("SELECIONE UMA OPÇÃO");
                Console.WriteLine("1- CALCULAR A AREA DO QUADRILATERO");
                Console.WriteLine("2- CALCULAR O PERIMETRO DO QUADRADO");
                Console.WriteLine("0-SAIR");

                opcao = Convert.ToInt32(Console.ReadLine());

                if (opcao == 1)
                {
                    Console.Clear();
                    Console.WriteLine("Insira o primeiro lado");
                    n1 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Insira o segundo lado");
                    n2 = Convert.ToDouble(Console.ReadLine());

                    resultado = n1 * n2;
                    Console.WriteLine("A area do quadrilatero é:" + resultado);
                    Console.ReadKey();
                }
                else if (opcao == 2)
                {
                    Console.Clear();
                    Console.WriteLine("Insira o valor do lado do quadrado");
                    n1 = Convert.ToDouble(Console.ReadLine());
                   

                    resultado = n1 + n2 + n3 + n4;
                    Console.WriteLine("O perimetro do quadrado é:" + resultado);
                    Console.ReadKey();
                }
             
                else if (opcao == 0)
                {
                    Console.WriteLine("Encerrando o programa...");
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("VOCE INSERIU UM VALOR INVÁLIDO");
                    Console.ReadKey();
                }
                
            }


            while (opcao != 0);
            Console.ReadKey();
        } 
        }
    
}
